export type Locale = 'fr' | 'en' | 'ua';

export interface Translations {
  hero: {
    titlePart1: string;
    titlePart2: string;
    subtitle: string;
    ctaAudit: string;
    ctaWebsite: string;
    ctaBook: string;
    ctaWhatsApp: string;
  };
  aiEmployees: {
    title: string;
    subtitle: string;
    roles: { title: string; desc: string; }[];
  };
  aiWorkflows: {
    title: string;
    items: { title: string; flow: string; }[];
  };
  architecture: {
    title: string;
  };
  packages: {
    title: string;
    items: { name: string; price?: string; description?: string; features: string[]; }[];
  };
  aiDemo: {
    title: string;
    subtitle: string;
    placeholderType: string;
    placeholderProblem: string;
    button: string;
    thinking: string;
    resultTitle: string;
    labels: {
      automationTitle: string;
      agentsTitle: string;
      workflowTitle: string;
    }
  };
  services: {
    title: string;
    items: {
      category: string;
      subItems: string[];
    }[];
  };
  industries: {
    title: string;
    items: {
      slug: string;
      name: string;
      painPoint: string;
      solution: string;
    }[];
  };
  industryDetails: {
    [slug: string]: {
      title: string;
      heroTitle: string;
      heroSubtitle: string;
      features: { title: string; desc: string }[];
      benefits: { title: string; desc: string }[];
      agents: { title: string; desc: string }[];
    };
  };
  beforeAfter: {
    title: string;
    before: {
      title: string;
      items: string[];
    };
    after: {
      title: string;
      items: string[];
    };
  };
  demo: {
    title: string;
    items: string[];
  };
  process: {
    title: string;
    items: string[];
  };
  audit: {
    title: string;
    description: string;
  };
  portfolio: {
    title: string;
    items: {
      name: string;
      result: string;
      automation: string;
      speed: string;
      conversion: string;
    }[];
  };
  testimonials: {
    title: string;
    items: {
      name: string;
      role: string;
      quote: string;
    }[];
  };
  faq: {
    title: string;
    items: {
      question: string;
      answer: string;
    }[];
  };
  automationPage: {
    title: string;
    description: string;
    sections: {
      workflows: string;
      diagrams: string;
      logic: string;
    };
    integrations: {
      title: string;
      items: string[];
    };
  };
  auditPage: {
    title: string;
    explanation: string;
    whatClientGets: string;
    examples: string[];
    formTitle: string;
  };
  contactPage: {
    title: string;
    subtitle: string;
    responsePromise: string;
    workingRegions: string;
    methods: {
      whatsapp: string;
      email: string;
      telegram: string;
    };
    formTitle: string;
    calendlyTitle: string;
  };
  techStack: {
    title: string;
  };
  leadForm: {
    businessName: string;
    businessPlaceholder: string;
    email: string;
    emailPlaceholder: string;
    website: string;
    websitePlaceholder: string;
    whatsapp: string;
    whatsappPlaceholder: string;
    googleMapsLink: string;
    googleMapsPlaceholder: string;
    btnInit: string;
    btnLoading: string;
    successTitle: string;
    successText: string;
  };
  finalCTA: {
    title: string;
    subtitle: string;
    ctaWebsite: string;
    ctaWhatsApp: string;
  };
  // Add other sections here as needed
}
