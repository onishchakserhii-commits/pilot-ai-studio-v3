import { Translations } from './types';

export const en: Translations = {
  hero: {
    titlePart1: "AI Systems in",
    titlePart2: "3–5 days.",
    subtitle: "I help small businesses in Switzerland rapidly launch modern websites, integrate AI tools, and automate routine tasks. More clients, less manual work.",
    ctaAudit: "Free AI Audit",
    ctaWebsite: "Build AI System",
    ctaBook: "Turnkey AI Employee",
    ctaWhatsApp: "Automate Business"
  },
  aiEmployees: {
    title: "Meet Your AI Employee",
    subtitle: "AI agents that answer clients, automate tasks and help your business grow.",
    roles: [
      { title: "AI Receptionist", desc: "Answers clients." },
      { title: "AI Sales Assistant", desc: "Processes leads." },
      { title: "AI Booking Agent", desc: "Accepts bookings." },
      { title: "AI Follow-up Agent", desc: "Reminds clients." },
      { title: "AI Content Agent", desc: "Creates posts and SEO content." },
      { title: "AI Support Agent", desc: "Responds 24/7." }
    ]
  },
  aiWorkflows: {
    title: "Autonomous Workflows",
    items: [
      { title: "Lead Generation", flow: "Client sends form → AI qualifies lead → WhatsApp reply → CRM entry → follow-up." },
      { title: "Booking System", flow: "Client books consultation → reminders → AI summary → Google Calendar sync." },
      { title: "Reputation Management", flow: "Business receives Google review → AI draft response → owner approval." }
    ]
  },
  architecture: {
    title: "AI System Architecture"
  },
  packages: {
    title: "Service Packages",
    items: [
      { 
        name: "Start — Fast Website", 
        price: "490–900 CHF",
        description: "For businesses that need a professional online look quickly.",
        features: ["1-page Landing", "Mobile Adaptation", "Contact Buttons", "Google Maps", "Lead Form", "Base SEO"] 
      },
      { 
        name: "Pro — Website + AI", 
        price: "1200–2500 CHF",
        description: "For businesses wanting more leads and automated communication.",
        features: ["3–5 page site", "AI Chatbot or assistant", "Lead Form", "Google Analytics", "Google Business Profile", "n8n Automation"] 
      },
      { 
        name: "Automation — Time Saver", 
        price: "700–3000 CHF",
        description: "For businesses tired of manual routine tasks.",
        features: ["Lead Automation", "Customer Responses", "Consultation Booking", "Reminders", "Google Sheets / CRM", "WhatsApp/Telegram Flows", "Follow-up Systems"] 
      }
    ]
  },
  aiDemo: {
    title: "AI Agent Blueprint",
    subtitle: "See which AI agents and workflows your business needs. Simple input, autonomous strategy.",
    placeholderType: "Business Type (e.g. Dental Clinic, Real Estate Agency)",
    placeholderProblem: "Main challenge (e.g. too many missed calls, slow lead response)",
    button: "Generate AI Blueprint",
    thinking: "AI Agent is analyzing your request...",
    resultTitle: "Your Autonomous Strategy",
    labels: {
      automationTitle: "Recommended Automations",
      agentsTitle: "AI Agents Needed",
      workflowTitle: "Execution Workflow"
    }
  },
  leadForm: {
    businessName: "Business Name *",
    businessPlaceholder: "E.g. Nexus Corp",
    email: "Email *",
    emailPlaceholder: "owner@nexus.co",
    website: "Website",
    websitePlaceholder: "https://nexus.co",
    whatsapp: "WhatsApp",
    whatsappPlaceholder: "+41 79...",
    googleMapsLink: "Google Maps Link",
    googleMapsPlaceholder: "https://maps.app.goo.gl/...",
    btnInit: "SUBMIT AUTOMATION REQUEST",
    btnLoading: "PROCESSING...",
    successTitle: "Proposal in Progress",
    successText: "Submit complete. Please book a consultation below to review your automation roadmap.",
  },
  finalCTA: {
    title: "Scale Your Operations Digitally",
    subtitle: "Implement AI systems that optimize time and enhance client acquisition.",
    ctaWebsite: "Start Project",
    ctaWhatsApp: "WhatsApp Consultation"
  },
  services: {
    title: "My Services",
    items: [
      { category: "AI Websites", subItems: ["landing pages in 3-5 days", "mobile adaptation", "vCard sites", "WordPress / Vercel"] },
      { category: "Automation", subItems: ["n8n integrations", "CRM systems", "auto-responses", "WhatsApp scenarios"] },
      { category: "Sales", subItems: ["AI chatbot", "lead forms", "lead automation", "follow-up"] },
      { category: "Marketing", subItems: ["SEO", "Google Analytics", "Google Ads", "Google Maps"] }
    ]
  },
  industries: {
    title: "Tailored AI Systems for Your Industry",
    items: [
      { slug: "bakery", name: "Bakery", painPoint: "Wasted time on order calls", solution: "WhatsApp auto-ordering" },
      { slug: "hotel", name: "Hotel", painPoint: "Manual check-in/booking", solution: "24/7 AI Receptionist" },
      { slug: "dental", name: "Dental", painPoint: "Missed appointments", solution: "Smart appointment reminders" },
      { slug: "salon", name: "Salon", painPoint: "Complex scheduling", solution: "Automated booking flow" },
      { slug: "restaurant", name: "Restaurant", painPoint: "Table management", solution: "AI table reservations" },
      { slug: "garage", name: "Garage", painPoint: "Customer status updates", solution: "Auto-status notifications" },
      { slug: "local-store", name: "Local Store", painPoint: "Inventory management", solution: "Automated stock alerts" },
      { slug: "services", name: "Services", painPoint: "Lead qualification", solution: "AI lead assistant" }
    ]
  },
  industryDetails: {
    bakery: {
      title: "AI for Bakeries",
      heroTitle: "Bake More, Manage Less",
      heroSubtitle: "Automate orders, streamline production tracking, and manage customer loyalty with intelligent AI workers.",
      features: [
        { title: "WhatsApp Order Bot", desc: "Automate incoming orders via WhatsApp and sync them directly with your production sheet." },
        { title: "Inventory Prediction", desc: "AI analyzes past sales to predict how many croissants you need to bake for tomorrow." },
        { title: "Loyalty Flow", desc: "Automatically send special offers to regular customers based on their favorite items." }
      ],
      benefits: [
        { title: "10+ Hours Saved", desc: "Stop answering the phone for simple orders. Let the AI handle the queue." },
        { title: "Zero Order Loss", desc: "No more messy handwritten notes. Every order is digitized instantly." }
      ],
      agents: [
        { title: "Baker Assistant", desc: "Notifies team about urgent orders." },
        { title: "Sales Agent", desc: "Upsells daily specials via automated messages." }
      ]
    },
    hotel: {
      title: "AI for Hospitality",
      heroTitle: "24/7 Digital Concierge",
      heroSubtitle: "Boost direct bookings and enhance guest experience with autonomous AI receptionists.",
      features: [
        { title: "AI Booking Assistant", desc: "Real-time room availability checks and instant booking confirmation 24/7." },
        { title: "Multi-language Support", desc: "Respond to guests in 80+ languages automatically." },
        { title: "Guest Profiling", desc: "AI remembers guest preferences for their next visit." }
      ],
      benefits: [
        { title: "Reduce OTA Fees", desc: "Drive more traffic to direct bookings through your AI-powered website." },
        { title: "Instant Response", desc: "Never keep a prospect waiting. 0.5s response time for any inquiry." }
      ],
      agents: [
        { title: "AI Concierge", desc: "Recommends local attractions and handles service requests." },
        { title: "Lead Agent", desc: "Captures business travel inquiries & group bookings." }
      ]
    },
    dental: {
      title: "AI for Dental Clinics",
      heroTitle: "Precision in Patient Care",
      heroSubtitle: "Reduce no-shows and automate patient onboarding with secure, HIPAA-compliant AI systems.",
      features: [
        { title: "Smart Reminders", desc: "Advanced WhatsApp reminders that allow patients to confirm or reschedule via chat." },
        { title: "Voice AI Reception", desc: "Handle routine calls and appointment booking even after hours." },
        { title: "Medical Lead Qual", desc: "AI qualifies potential patients for high-value procedures like implants." }
      ],
      benefits: [
        { title: "30% Fewer No-Shows", desc: "Automatic interactive reminders ensure seats are filled." },
        { title: "Faster Onboarding", desc: "Collect patient data via AI before they even step into the clinic." }
      ],
      agents: [
        { title: "Medical Admin", desc: "Manages the calendar across multiple doctors." },
        { title: "Follow-up Specialist", desc: "Contacts patients for post-treatment feedback." }
      ]
    },
    restaurant: {
      title: "AI for Gastro & Restaurants",
      heroTitle: "Smart Dining Experience",
      heroSubtitle: "Optimize table occupancy and automate reservations with intelligent AI assistants.",
      features: [
        { title: "Table Reservation AI", desc: "Integrated booking flow that prevents overbooking and manages peak hours." },
        { title: "Digital Menu Assistant", desc: "Interactive menu where AI recommends dishes based on diet or taste." },
        { title: "Review Management", desc: "AI creates drafts for Google Reviews to maintain high rating." }
      ],
      benefits: [
        { title: "Full House Optimization", desc: "Better seat organization through intelligent scheduling." },
        { title: "Higher Average Check", desc: "AI suggests wine pairings and desserts during the booking process." }
      ],
      agents: [
        { title: "Head Waiter AI", desc: "Handles reservations and dietary inquiries." },
        { title: "Promotion Agent", desc: "Sends invitations for special events and holidays." }
      ]
    }
  },
  demo: {
    title: "AI Automation Flow",
    items: ["AI Chatbot", "Automation Flow", "Lead Pipeline", "WhatsApp Response", "Google Sheets Sync", "Follow-up Workflow"]
  },
  process: {
    title: "Our Process",
    items: ["Business audit", "AI strategy", "Website generation", "Automation setup", "Launch", "Optimization"]
  },
  audit: {
    title: "Get Your Free AI Audit",
    description: "Submit your details to get personalized automation recommendations."
  },
  portfolio: {
    title: "Selected Works",
    items: [
      { name: "Bakery", result: "+40% orders", automation: "WhatsApp flow", speed: "1.2s", conversion: "15%" },
      { name: "AI Hotel", result: "+25% direct bookings", automation: "AI Booking Agent", speed: "0.8s", conversion: "12%" },
      { name: "Dental", result: "+30% appointments", automation: "Auto-reminders", speed: "1.5s", conversion: "20%" },
      { name: "Salon", result: "+50% bookings", automation: "Smart calendar", speed: "1.0s", conversion: "18%" },
      { name: "Landing Page", result: "+20% leads", automation: "Lead capture", speed: "0.5s", conversion: "25%" }
    ]
  },
  testimonials: {
    title: "Client Success Stories",
    items: [
      { name: "Maria S.", role: "Bakery Owner", quote: "The WhatsApp automation transformed how we take orders! It saved us 10+ hours a week." },
      { name: "Thomas K.", role: "Hotel Manager", quote: "AI booking agent is always online and our bookings have increased significantly." },
      { name: "Dr. Elena B.", role: "Dentist", quote: "Our appointment show-up rate improved drastically with automated reminders." }
    ]
  },
  faq: {
    title: "Frequently Asked Questions",
    items: [
      { question: "How fast can you build a website?", answer: "We can build a base website in as fast as 48 hours depending on requirements." },
      { question: "Do you support French?", answer: "Yes, we fully support multi-language websites including French." },
      { question: "Can you automate WhatsApp?", answer: "Yes, we can integrate WhatsApp with AI to automate conversations." },
      { question: "What is n8n?", answer: "n8n is a powerful, low-code workflow automation tool that connects your apps." },
      { question: "Can AI answer clients automatically?", answer: "Yes, AI agents can be trained to answer customer queries automatically." },
      { question: "Can you connect Google Analytics?", answer: "Absolutely, we can integrate Google Analytics for detailed insights." },
      { question: "Can you redesign existing websites?", answer: "Yes, we can modernize and optimize existing websites." }
    ]
  },
  automationPage: {
    title: "Automation",
    description: "Streamline your business with intelligent workflows.",
    sections: {
      workflows: "Smart Workflows",
      diagrams: "Visual Diagrams",
      logic: "Automation Logic"
    },
    integrations: {
      title: "Integrations",
      items: ["WhatsApp", "Gmail", "Telegram", "Google Sheets", "Stripe", "OpenAI", "CRM"]
    }
  },
  auditPage: {
    title: "Free AI Audit",
    explanation: "A precise analysis of your business processes to identify high-ROI automation opportunities.",
    whatClientGets: "A tailored strategic roadmap detailing actionable digital solutions.",
    examples: ["Lead capture & nurturing strategy", "AI assistant integration overview", "Workflow optimization plan"],
    formTitle: "Request Custom Audit"
  },
  contactPage: {
    title: "Contact Us",
    subtitle: "Initiate your digital transformation today.",
    responsePromise: "Our Swiss-based team ensures a prompt and precise response.",
    workingRegions: "Serving clients in Vaud, Geneva, and globally.",
    methods: {
      whatsapp: "Chat on WhatsApp",
      email: "Send us an Email",
      telegram: "Message on Telegram"
    },
    formTitle: "Send a Message",
    calendlyTitle: "Schedule a Call"
  },
  techStack: {
    title: "Powered by Modern Tech Stack"
  },
  beforeAfter: {
    title: "Transform Your Business",
    before: {
      title: "Before",
      items: ["Old website", "No leads", "No automation", "Slow mobile performance"]
    },
    after: {
      title: "After",
      items: ["AI-powered website", "Automated lead system", "WhatsApp integration", "Multilingual support", "AI Assistant", "Advanced analytics"]
    }
  }
};
