import { Translations } from './types';

export const fr: Translations = {
  hero: {
    titlePart1: "Systèmes IA",
    titlePart2: "en 3–5 jours.",
    subtitle: "J’aide les petites entreprises en Suisse à lancer rapidement des sites web modernes, à intégrer des outils d’IA et à automatiser les tâches répétitives. Plus de clients, moins de travail manuel.",
    ctaAudit: "Audit IA Gratuit",
    ctaWebsite: "Construire un Système IA",
    ctaBook: "Employé IA Clé en Main",
    ctaWhatsApp: "Automatiser mon Entreprise"
  },
  aiEmployees: {
    title: "Rencontrez Votre Employé IA",
    subtitle: "Des agents IA qui répondent aux clients, automatisent les tâches et aident votre entreprise à se développer.",
    roles: [
      { title: "Réceptionniste IA", desc: "Répond aux clients." },
      { title: "Assistant Commercial IA", desc: "Traite les prospects." },
      { title: "Agent de Réservation IA", desc: "Accepte les réservations." },
      { title: "Agent de Suivi IA", desc: "Relance les clients." },
      { title: "Agent de Contenu IA", desc: "Crée des posts et du contenu SEO." },
      { title: "Agent de Support IA", desc: "Répond 24/7." }
    ]
  },
  aiWorkflows: {
    title: "Workflows Autonomes",
    items: [
      { title: "Génération de Leads", flow: "Client envoie le formulaire → l'IA qualifie le prospect → Réponse WhatsApp → Entrée CRM → suivi." },
      { title: "Système de Réservation", flow: "Le client réserve une consultation → rappels → résumé IA → synchronisation Google Calendar." },
      { title: "Gestion de Réputation", flow: "L'entreprise reçoit un avis Google → brouillon de réponse IA → approbation du propriétaire." }
    ]
  },
  architecture: {
    title: "Architecture du système IA"
  },
  packages: {
    title: "Mes Forfaits",
    items: [
      { 
        name: "Start — Site Rapide", 
        price: "490–900 CHF",
        description: "Pour les entreprises qui doivent être professionnelles en ligne rapidement.",
        features: ["Landing 1 page", "Adaptation mobile", "Boutons de contact", "Google Maps", "Formulaire", "SEO de base"] 
      },
      { 
        name: "Pro — Site + IA", 
        price: "1200–2500 CHF",
        description: "Pour les entreprises qui veulent plus de leads et une communication auto.",
        features: ["Site 3–5 pages", "Chatbot IA ou assistant", "Formulaire", "Google Analytics", "Google Business Profile", "Automatisation n8n"] 
      },
      { 
        name: "Automation — Gain de temps", 
        price: "700–3000 CHF",
        description: "Pour les entreprises fatiguées de la routine manuelle.",
        features: ["Auto-leads", "Réponses aux clients", "Prise de RDV", "Rappels", "Google Sheets / CRM", "WhatsApp/Telegram", "Systèmes de suivi"] 
      }
    ]
  },
  aiDemo: {
    title: "Plan d'Agent IA",
    subtitle: "Découvrez quels agents IA et workflows votre entreprise nécessite. Une entrée simple, une stratégie autonome.",
    placeholderType: "Type d'entreprise (ex: Clinique dentaire, Agence immobilière)",
    placeholderProblem: "Défi principal (ex: trop d'appels manqués, réponse lente aux prospects)",
    button: "Générer le Plan IA",
    thinking: "L'agent IA analyse votre demande...",
    resultTitle: "Votre Stratégie Autonome",
    labels: {
      automationTitle: "Automatisations Recommandées",
      agentsTitle: "Agents IA Nécessaires",
      workflowTitle: "Workflow d'Exécution"
    }
  },
  leadForm: {
    businessName: "Nom de l'entreprise *",
    businessPlaceholder: "Ex: Nexus Corp",
    email: "Email *",
    emailPlaceholder: "owner@nexus.co",
    website: "Site Web",
    websitePlaceholder: "https://nexus.co",
    whatsapp: "WhatsApp",
    whatsappPlaceholder: "+41 79...",
    googleMapsLink: "Lien Google Maps",
    googleMapsPlaceholder: "https://maps.app.goo.gl/...",
    btnInit: "DEMANDER UNE AUTOMATISATION",
    btnLoading: "TRAITEMENT...",
    successTitle: "Proposition en cours",
    successText: "Demande envoyée. Veuillez planifier une consultation ci-dessous pour examiner votre proposition.",
  },
  finalCTA: {
    title: "Digitalisez vos Opérations",
    subtitle: "Implémentez des systèmes IA qui optimisent le temps et accélèrent l'acquisition de clients.",
    ctaWebsite: "Démarrer le Projet",
    ctaWhatsApp: "Consultation WhatsApp"
  },
  services: {
    title: "Mes Services",
    items: [
      { category: "Sites IA", subItems: ["landing pages en 3-5j", "adaptation mobile", "vCard sites", "WordPress / Vercel"] },
      { category: "Automatisation", subItems: ["intégrations n8n", "systèmes CRM", "auto-réponses", "scénarios WhatsApp"] },
      { category: "Ventes", subItems: ["chatbot IA", "formulaires leads", "automatisation leads", "follow-up"] },
      { category: "Marketing", subItems: ["SEO", "Google Analytics", "Google Ads", "Google Maps"] }
    ]
  },
  industries: {
    title: "Systèmes IA sur mesure pour votre industrie",
    items: [
      { slug: "bakery", name: "Boulangerie", painPoint: "Temps perdu aux appels", solution: "Commande WhatsApp auto" },
      { slug: "hotel", name: "Hôtel", painPoint: "Check-in manuel", solution: "Réceptionniste IA 24/7" },
      { slug: "dental", name: "Dentaire", painPoint: "Rendez-vous manqués", solution: "Rappels automatiques" },
      { slug: "salon", name: "Salon", painPoint: "Planning complexe", solution: "Réservation automatisée" },
      { slug: "restaurant", name: "Restaurant", painPoint: "Gestion des tables", solution: "Réservation IA" },
      { slug: "garage", name: "Garage", painPoint: "Suivi client", solution: "Auto-notifications" },
      { slug: "local-store", name: "Commerce", painPoint: "Gestion du stock", solution: "Alertes automatiques" },
      { slug: "services", name: "Services", painPoint: "Lead qualification", solution: "Assistant IA" }
    ]
  },
  industryDetails: {
    bakery: {
      title: "IA pour Boulangeries",
      heroTitle: "Cuisez plus, gérez moins",
      heroSubtitle: "Automatisez les commandes, simplifiez le suivi de production et gérez la fidélité client avec des agents IA.",
      features: [
        { title: "Bot de commande WhatsApp", desc: "Automatisez les commandes via WhatsApp et synchronisez-les avec votre fiche de production." },
        { title: "Prédiction des stocks", desc: "L'IA analyse les ventes passées pour prédire vos besoins de production pour demain." },
        { title: "Flux de fidélité", desc: "Envoyez automatiquement des offres spéciales à vos clients réguliers." }
      ],
      benefits: [
        { title: "Gagnez +10h/semaine", desc: "Laissez l'IA gérer les commandes simples pendant que vous vous concentrez sur la qualité." },
        { title: "Zéro perte de commande", desc: "Chaque commande est numérisée instantanément, plus de notes manuscrites." }
      ],
      agents: [
        { title: "Assistant Boulanger", desc: "Notifie l'équipe des commandes urgentes." },
        { title: "Agent de Vente", desc: "Propose les spécialités du jour via messages automatisés." }
      ]
    },
    hotel: {
      title: "IA pour l'Hôtellerie",
      heroTitle: "Concierge numérique 24/7",
      heroSubtitle: "Boostez les réservations directes et améliorez l'expérience client avec des réceptionnistes IA autonomes.",
      features: [
        { title: "Assistant de réservation IA", desc: "Vérification des disponibilités en temps réel et confirmation instantanée 24/7." },
        { title: "Support multilingue", desc: "Répondez automatiquement à vos clients dans plus de 80 langues." },
        { title: "Profilage des clients", desc: "L'IA se souvient des préférences des clients pour leur prochaine visite." }
      ],
      benefits: [
        { title: "Réduisez les frais OTA", desc: "Générez plus de réservations directes via votre site propulsé par l'IA." },
        { title: "Réponse instantanée", desc: "Ne faites plus attendre vos prospects. Temps de réponse de 0.5s." }
      ],
      agents: [
        { title: "Concierge IA", desc: "Recommande des attractions locales et gère les demandes de service." },
        { title: "Agent de Leads", desc: "Capture les demandes de voyages d'affaires et les réservations de groupe." }
      ]
    },
    dental: {
      title: "IA pour Cliniques Dentaires",
      heroTitle: "Précision dans les soins",
      heroSubtitle: "Réduisez les absences et automatisez l'accueil des patients avec des systèmes IA sécurisés.",
      features: [
        { title: "Rappels intelligents", desc: "Rappels WhatsApp avancés permettant de confirmer ou déplacer un RDV par chat." },
        { title: "Réception Vocale IA", desc: "Gérez les appels de routine et la prise de RDV même après la fermeture." },
        { title: "Qualif de leads médicaux", desc: "L'IA qualifie les patients pour les soins à haute valeur ajoutée comme les implants." }
      ],
      benefits: [
        { title: "-30% de rendez-vous manqués", desc: "Les rappels interactifs assurent que votre planning reste rempli." },
        { title: "Accueil plus rapide", desc: "Collectez les données patients via l'IA avant leur arrivée en clinique." }
      ],
      agents: [
        { title: "Admin Médical", desc: "Gère le calendrier de plusieurs praticiens simultanément." },
        { title: "Spécialiste de Suivi", desc: "Contacte les patients après le traitement pour recueillir leurs avis." }
      ]
    },
    restaurant: {
      title: "IA pour la Restauration",
      heroTitle: "Expérience gastronomique intelligente",
      heroSubtitle: "Optimisez l'occupation des tables et automatisez les réservations avec des assistants IA.",
      features: [
        { title: "IA de réservation de table", desc: "Flux de réservation intégré qui évite le surbooking et gère les heures de pointe." },
        { title: "Assistant menu numérique", desc: "Menu interactif où l'IA recommande des plats selon les goûts ou régimes." },
        { title: "Gestion des avis", desc: "L'IA prépare des réponses pour vos avis Google afin de maintenir une bonne note." }
      ],
      benefits: [
        { title: "Optimisation de la salle", desc: "Meilleure organisation grâce à une planification intelligente." },
        { title: "Ticket moyen plus élevé", desc: "L'IA suggère des accords mets-vins dès la réservation." }
      ],
      agents: [
        { title: "Maître d'hôtel IA", desc: "Gère les réservations et répond aux demandes sur le menu." },
        { title: "Agent de Promotion", desc: "Envoie des invitations pour les soirées spéciales et les événements." }
      ]
    }
  },
  demo: {
    title: "Flux d'automatisation IA",
    items: ["Chatbot IA", "Flux d'automatisation", "Pipeline de leads", "Réponse WhatsApp", "Sync Google Sheets", "Flux de suivi"]
  },
  process: {
    title: "Notre processus",
    items: ["Audit commercial", "Stratégie IA", "Génération de site web", "Configuration automatisée", "Lancement", "Optimisation"]
  },
  audit: {
    title: "Obtenez votre audit IA gratuit",
    description: "Soumettez vos détails pour obtenir des recommandations d'automatisation personnalisées."
  },
  portfolio: {
    title: "Travaux sélectionnés",
    items: [
      { name: "Boulangerie", result: "+40% commandes", automation: "Flux WhatsApp", speed: "1.2s", conversion: "15%" },
      { name: "Hôtel IA", result: "+25% résas directes", automation: "Agent de réservation IA", speed: "0.8s", conversion: "12%" },
      { name: "Dentiste", result: "+30% rdv", automation: "Auto-rappels", speed: "1.5s", conversion: "20%" },
      { name: "Salon", result: "+50% résas", automation: "Calendrier intelligent", speed: "1.0s", conversion: "18%" },
      { name: "Landing Page", result: "+20% leads", automation: "Capture de leads", speed: "0.5s", conversion: "25%" }
    ]
  },
  testimonials: {
    title: "Témoignages",
    items: [
      { name: "Maria S.", role: "Propriétaire", quote: "L'automatisation WhatsApp a transformé notre prise de commandes ! Un gain de 10h par semaine." },
      { name: "Thomas K.", role: "Directeur d'hôtel", quote: "L'agent de réservation IA est toujours en ligne, nos réservations ont augmenté." },
      { name: "Dr. Elena B.", role: "Dentiste", quote: "Notre taux de présence a radicalement augmenté grâce aux rappels automatiques." }
    ]
  },
  faq: {
    title: "Questions Fréquentes",
    items: [
      { question: "À quelle vitesse pouvez-vous construire un site web ?", answer: "Nous pouvons créer un site web de base en seulement 48 heures, selon vos besoins." },
      { question: "Supportez-vous le français ?", answer: "Oui, nous prenons entièrement en charge les sites web multilingues, y compris le français." },
      { question: "Pouvez-vous automatiser WhatsApp ?", answer: "Oui, nous pouvons intégrer WhatsApp à l'IA pour automatiser les conversations." },
      { question: "Qu'est-ce que n8n ?", answer: "n8n est un outil d'automatisation de flux de travail 'low-code' puissant qui connecte vos applications." },
      { question: "L'IA peut-elle répondre automatiquement aux clients ?", answer: "Oui, les agents IA peuvent être formés pour répondre automatiquement aux demandes des clients." },
      { question: "Pouvez-vous connecter Google Analytics ?", answer: "Absolument, nous pouvons intégrer Google Analytics pour obtenir des informations détaillées." },
      { question: "Pouvez-vous redessiner des sites existants ?", answer: "Oui, nous pouvons moderniser et optimiser les sites web existants." }
    ]
  },
  automationPage: {
    title: "Automatisation",
    description: "Simplifiez votre entreprise avec des workflows intelligents.",
    sections: {
      workflows: "Workflows Intelligents",
      diagrams: "Diagrammes Visuels",
      logic: "Logique d'Automatisation"
    },
    integrations: {
      title: "Intégrations",
      items: ["WhatsApp", "Gmail", "Telegram", "Google Sheets", "Stripe", "OpenAI", "CRM"]
    }
  },
  auditPage: {
    title: "Audit IA Gratuit",
    explanation: "Une analyse précise de vos processus pour identifier les opportunités d'automatisation à haut retour sur investissement.",
    whatClientGets: "Une feuille de route stratégique sur-mesure détaillant les solutions digitales actionnables.",
    examples: ["Stratégie d'acquisition de leads", "Aperçu d'intégration d'assistant IA", "Plan d'optimisation des flux"],
    formTitle: "Demander un Audit Personnalisé"
  },
  contactPage: {
    title: "Contactez-nous",
    subtitle: "Initiez votre transformation digitale dès aujourd'hui.",
    responsePromise: "Notre équipe basée en Suisse vous garantit une réponse rapide et précise.",
    workingRegions: "Au service des clients dans le canton de Vaud, à Genève, et à l'international.",
    methods: {
      whatsapp: "Discuter sur WhatsApp",
      email: "Envoyez-nous un Email",
      telegram: "Message sur Telegram"
    },
    formTitle: "Envoyer un Message",
    calendlyTitle: "Planifier un Appel"
  },
  techStack: {
    title: "Propulsé par des Technologies Modernes",
  },
  beforeAfter: {
    title: "Transformez votre entreprise",
    before: {
      title: "Avant",
      items: ["Ancien site web", "Pas de leads", "Pas d'automatisation", "Performances mobiles lentes"]
    },
    after: {
      title: "Après",
      items: ["Site web IA", "Système de leads", "WhatsApp", "Multilingue", "Assistant IA", "Analytique"]
    }
  }
};
