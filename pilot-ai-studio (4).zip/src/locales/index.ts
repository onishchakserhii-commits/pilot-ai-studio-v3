import { Locale, Translations } from './types';
import { en } from './en';
import { fr } from './fr';
import { ua } from './ua';

export const translations: Record<Locale, Translations> = {
  en,
  fr,
  ua
};
