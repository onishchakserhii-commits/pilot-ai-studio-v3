/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { Home } from './pages/Home';
import { Automation } from './pages/Automation';
import { Audit } from './pages/Audit';
import { Portfolio } from './pages/Portfolio';
import { Contact } from './pages/Contact';
import { IndustryDetail } from './pages/IndustryDetail';
import { Navbar } from './components/Navbar';
import { LanguageProvider } from './context/LanguageContext';
import { SettingsProvider } from './context/SettingsContext';
import { CursorGlow } from './components/CursorGlow';

export default function App() {
  return (
    <LanguageProvider>
      <SettingsProvider>
        <HelmetProvider>
          <CursorGlow />
          <BrowserRouter>
            <Navbar />
            <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/industry/:slug" element={<IndustryDetail />} />
            <Route path="/automation" element={<Automation />} />
            <Route path="/audit" element={<Audit />} />
            <Route path="/portfolio" element={<Portfolio />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </BrowserRouter>
      </HelmetProvider>
    </SettingsProvider>
  </LanguageProvider>
);
}
