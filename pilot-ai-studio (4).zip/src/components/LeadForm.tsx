import React, { useState } from 'react';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { useLanguage } from '../context/LanguageContext';
import { InlineWidget } from 'react-calendly';

export const LeadForm = () => {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const { t } = useLanguage();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    const formData = new FormData(e.currentTarget);
    const data = {
        businessName: formData.get('businessName'),
        website: formData.get('website'),
        googleMapsLink: formData.get('googleMapsLink'),
        whatsapp: formData.get('whatsapp'),
        email: formData.get('email'),
        createdAt: serverTimestamp()
    };

    try {
      await addDoc(collection(db, 'leads'), data);
      setSuccess(true);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'leads');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="bg-black/40 backdrop-blur-3xl border border-white/5 shadow-inner p-10 rounded-3xl space-y-6">
        <h3 className="text-2xl font-medium mb-2">{t.leadForm.successTitle}</h3>
        <p className="text-gray-400 mb-8 font-light">{t.leadForm.successText}</p>
        <div className="h-[600px] w-full bg-white/5 rounded-2xl overflow-hidden">
          <InlineWidget url="https://calendly.com/onishchakserhii" styles={{ height: '100%' }} />
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-black/40 backdrop-blur-3xl border border-white/5 shadow-inner p-10 rounded-3xl space-y-6">
      <div className="space-y-2">
        <Label htmlFor="businessName" className="font-mono text-xs tracking-widest uppercase text-gray-400">{t.leadForm.businessName}</Label>
        <Input required name="businessName" placeholder={t.leadForm.businessPlaceholder} className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-6 font-light" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="email" className="font-mono text-xs tracking-widest uppercase text-gray-400">{t.leadForm.email}</Label>
        <Input required type="email" name="email" placeholder={t.leadForm.emailPlaceholder} className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-6 font-light" />
      </div>
      <div className="grid sm:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="website" className="font-mono text-xs tracking-widest uppercase text-gray-400">{t.leadForm.website}</Label>
          <Input name="website" placeholder={t.leadForm.websitePlaceholder} className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-6 font-light" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="whatsapp" className="font-mono text-xs tracking-widest uppercase text-gray-400">{t.leadForm.whatsapp}</Label>
          <Input name="whatsapp" placeholder={t.leadForm.whatsappPlaceholder} className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-6 font-light" />
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="googleMapsLink" className="font-mono text-xs tracking-widest uppercase text-gray-400">{t.leadForm.googleMapsLink}</Label>
        <Input name="googleMapsLink" placeholder={t.leadForm.googleMapsPlaceholder} className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-6 font-light" />
      </div>
      <Button disabled={loading} className="w-full bg-white text-background hover:bg-gray-200 hover:scale-[1.02] transition-all rounded-xl py-6 font-medium tracking-wide uppercase text-sm shadow-[0_0_20px_rgba(255,255,255,0.1)]">
        {loading ? t.leadForm.btnLoading : t.leadForm.btnInit}
      </Button>
    </form>
  );
};
