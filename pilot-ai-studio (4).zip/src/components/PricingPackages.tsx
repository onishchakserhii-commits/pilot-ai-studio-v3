import { motion } from 'framer-motion';
import { Check, Rocket, Zap, Clock } from 'lucide-react';
import { ScrollReveal } from './ScrollReveal';
import { useLanguage } from '../context/LanguageContext';

export const PricingPackages = () => {
  const { t } = useLanguage();

  const getIcon = (index: number) => {
    switch (index) {
      case 0: return <Rocket className="w-6 h-6" />;
      case 1: return <Zap className="w-6 h-6" />;
      case 2: return <Clock className="w-6 h-6" />;
      default: return <Rocket className="w-6 h-6" />;
    }
  };

  return (
    <ScrollReveal>
      <section className="max-w-7xl mx-auto px-6 mb-32 relative z-10 w-full" id="pricing">
        <h2 className="text-4xl md:text-5xl font-medium mb-16 text-center tracking-tight">{t.packages.title}</h2>
        <div className="grid md:grid-cols-3 gap-8 items-stretch">
          {t.packages.items.map((pkg, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className={`glass-panel p-8 md:p-10 rounded-[2rem] relative overflow-hidden flex flex-col group border-white/5 hover:border-indigo-500/30 transition-all duration-500 ${
                i === 1 ? 'border-indigo-500/40 shadow-[0_0_80px_rgba(99,102,241,0.05)] scale-105 z-20 bg-white/[0.02]' : ''
              }`}
            >
              {/* Background Glow */}
              <div className={`absolute -top-24 -right-24 w-64 h-64 blur-[100px] pointer-events-none transition-opacity duration-700 opacity-20 group-hover:opacity-40 ${
                i === 1 ? 'bg-indigo-500' : 'bg-gray-500'
              }`} />

              {i === 1 && (
                <div className="absolute top-0 inset-x-0 mx-auto text-center py-1.5 bg-indigo-500/10 text-indigo-300 text-[10px] tracking-[0.2em] font-mono uppercase border-b border-indigo-500/20">
                  Most Popular
                </div>
              )}

              <div className="flex items-center gap-4 mb-6 mt-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border border-white/10 ${i === 1 ? 'bg-indigo-500/10 text-indigo-400' : 'bg-white/5 text-gray-400'}`}>
                  {getIcon(i)}
                </div>
                <h3 className={`text-xl font-medium text-white group-hover:text-indigo-200 transition-colors`}>{pkg.name.split(' — ')[0]}</h3>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-2 mb-2">
                  <span className="text-4xl font-medium text-white tracking-tighter">{pkg.price?.split(' ')[0]}</span>
                  <span className="text-gray-400 text-sm font-light uppercase tracking-widest">{pkg.price?.split(' ')[1]}</span>
                </div>
                <p className="text-gray-400 text-sm font-light leading-relaxed min-h-[40px]">
                  {pkg.description}
                </p>
              </div>

              <div className="h-px w-full bg-white/5 mb-8" />

              <ul className="flex-1 space-y-4 mb-10 relative z-10">
                {pkg.features.map((feat, j) => (
                  <li key={j} className="flex items-start text-sm text-gray-400 font-light group/item">
                    <Check className={`w-4 h-4 mr-3 mt-0.5 shrink-0 transition-colors ${i === 1 ? 'text-indigo-400' : 'text-indigo-400/50'}`} />
                    <span className="group-hover/item:text-gray-300 transition-colors">{feat}</span>
                  </li>
                ))}
              </ul>

              <a href="#contact" className={`w-full py-4 text-center rounded-2xl text-xs font-mono tracking-[0.1em] uppercase transition-all relative z-10 border overflow-hidden group/btn ${
                i === 1 
                  ? 'bg-indigo-600 border-indigo-500 text-white hover:bg-indigo-500 shadow-[0_10px_30px_rgba(99,102,241,0.2)]' 
                  : 'border-white/10 text-white hover:bg-white/5 hover:border-white/20'
              }`}>
                <span className="relative z-10">{t.hero.ctaWebsite}</span>
              </a>
            </motion.div>
          ))}
        </div>
      </section>
    </ScrollReveal>
  );
};
