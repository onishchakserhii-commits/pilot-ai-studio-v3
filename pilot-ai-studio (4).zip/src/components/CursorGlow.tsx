import { useEffect, useState } from 'react';
import { motion, useSpring } from 'motion/react';

export const CursorGlow = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);

  // Smooth out the mouse movement
  const springX = useSpring(0, { stiffness: 300, damping: 40 });
  const springY = useSpring(0, { stiffness: 300, damping: 40 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
      springX.set(e.clientX - 200); // 200 is half of width/height (400px)
      springY.set(e.clientY - 200);
      if (!isVisible) setIsVisible(true);
    };

    const handleMouseLeave = () => setIsVisible(false);
    const handleMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', handleMouseMove);
    document.documentElement.addEventListener('mouseleave', handleMouseLeave);
    document.documentElement.addEventListener('mouseenter', handleMouseEnter);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.documentElement.removeEventListener('mouseleave', handleMouseLeave);
      document.documentElement.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [isVisible, springX, springY]);

  return (
    <motion.div
      style={{
        x: springX,
        y: springY,
        opacity: isVisible ? 1 : 0,
      }}
      className="pointer-events-none fixed top-0 left-0 w-[400px] h-[400px] bg-indigo-500/10 rounded-full blur-[100px] z-0 mix-blend-screen transition-opacity duration-500"
    />
  );
};
