import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Settings, Shield, Key, Link as LinkIcon, Globe } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { useLanguage } from '../context/LanguageContext';

export const SettingsModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  const { settings, updateSettings } = useSettings();
  const { locale } = useLanguage();
  const [localSettings, setLocalSettings] = useState(settings);

  const handleSave = () => {
    updateSettings(localSettings);
    onClose();
  };

  const labels = {
    ua: {
      title: 'Налаштування AI & Шлюзів',
      subtitle: 'Встановіть ключі для активації автономних функцій',
      gemini: 'Gemini API Key',
      n8nUrl: 'n8n Webhook URL',
      n8nKey: 'n8n API Key',
      whatsapp: 'WhatsApp Business API Key',
      save: 'Зберегти конфігурацію',
      notice: 'Ключі зберігаються локально у вашому браузері.'
    },
    en: {
      title: 'AI & Gateway Settings',
      subtitle: 'Configure keys to activate autonomous functions',
      gemini: 'Gemini API Key',
      n8nUrl: 'n8n Webhook URL',
      n8nKey: 'n8n API Key',
      whatsapp: 'WhatsApp Business API Key',
      save: 'Save Configuration',
      notice: 'Keys are stored locally in your browser.'
    },
    fr: {
      title: 'Paramètres IA & Passerelles',
      subtitle: 'Configurez les clés pour activer les fonctions autonomes',
      gemini: 'Clé API Gemini',
      n8nUrl: 'URL Webhook n8n',
      n8nKey: 'Clé API n8n',
      whatsapp: 'Clé API WhatsApp Business',
      save: 'Enregistrer la configuration',
      notice: 'Les clés sont stockées localement dans votre navigateur.'
    }
  };

  const t = labels[locale as keyof typeof labels] || labels.en;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100]"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-xl z-[101] px-6"
          >
            <div className="glass-panel p-8 md:p-10 rounded-[2.5rem] border border-white/10 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 blur-[80px]" />
              
              <button 
                onClick={onClose}
                className="absolute top-6 right-6 p-2 text-gray-400 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>

              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                  <Shield size={24} />
                </div>
                <div>
                  <h2 className="text-2xl font-medium text-white">{t.title}</h2>
                  <p className="text-gray-400 text-sm font-light">{t.subtitle}</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-mono text-gray-500 uppercase tracking-widest flex items-center gap-2">
                    <Key size={12} /> {t.gemini}
                  </label>
                  <Input 
                    type="password"
                    value={localSettings.geminiKey}
                    onChange={(e) => setLocalSettings({ ...localSettings, geminiKey: e.target.value })}
                    placeholder="Enter Gemini Key..."
                    className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-6 font-light"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-mono text-gray-500 uppercase tracking-widest flex items-center gap-2">
                      <Globe size={12} /> URL n8n
                    </label>
                    <Input 
                      value={localSettings.n8nUrl}
                      onChange={(e) => setLocalSettings({ ...localSettings, n8nUrl: e.target.value })}
                      placeholder="https://n8n.your-instance.com"
                      className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-4 font-light text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-mono text-gray-500 uppercase tracking-widest flex items-center gap-2">
                      <Key size={12} /> n8n Key
                    </label>
                    <Input 
                      type="password"
                      value={localSettings.n8nKey}
                      onChange={(e) => setLocalSettings({ ...localSettings, n8nKey: e.target.value })}
                      className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-4 font-light text-sm"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-mono text-gray-500 uppercase tracking-widest flex items-center gap-2">
                    <LinkIcon size={12} /> {t.whatsapp}
                  </label>
                  <Input 
                    type="password"
                    value={localSettings.whatsappKey}
                    onChange={(e) => setLocalSettings({ ...localSettings, whatsappKey: e.target.value })}
                    className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-6 font-light"
                  />
                </div>

                <div className="pt-4 space-y-4">
                  <Button 
                    onClick={handleSave}
                    className="w-full bg-indigo-600 text-white hover:bg-indigo-500 py-6 rounded-xl font-medium tracking-wide shadow-[0_0_20px_rgba(99,102,241,0.2)]"
                  >
                    {t.save}
                  </Button>
                  <p className="text-[10px] text-center text-gray-500 font-mono italic">
                    {t.notice}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
