import { Helmet } from 'react-helmet-async';
import { useLanguage } from '../context/LanguageContext';

export const SEO = ({ title, description, url = 'https://pilot-ai.studio' }: { title?: string, description?: string, url?: string }) => {
  const { locale } = useLanguage();

  const defaultTitle = locale === 'fr' 
    ? "Pilot AI Studio | Création de Sites IA & Automatisation en Suisse"
    : locale === 'ua'
    ? "Pilot AI Studio | Створення AI Сайтів та Автоматизація у Швейцарії"
    : "Pilot AI Studio | AI Websites & Business Automation in Switzerland";

  const defaultDescription = locale === 'fr'
    ? "Création de sites internet avec intelligence artificielle et automatisation n8n pour les entreprises suisses (Vaud, Montreux, Lausanne). Solutions sur-mesure."
    : locale === 'ua'
    ? "Створення сайтів зі штучним інтелектом та n8n автоматизація для бізнесу у Швейцарії. Підвищіть конверсію та оптимізуйте процеси."
    : "AI-powered web design and n8n automation for businesses in Switzerland. Optimize workflows and boost conversion rates in Vaud, Montreux, Lausanne.";

  const keywords = "AI website Switzerland, création site IA Suisse, automation entreprise Suisse, AI automation Vaud, création site Montreux, site internet Lausanne, n8n automation Switzerland";

  const currentTitle = title ? `${title} | Pilot AI Studio` : defaultTitle;
  const currentDescription = description || defaultDescription;

  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "Pilot AI Studio",
    "image": "https://pilot-ai.studio/og-image.jpg",
    "url": url,
    "telephone": "+41796186852",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Montreux",
      "addressRegion": "Vaud",
      "addressCountry": "CH"
    },
    "description": defaultDescription,
    "priceRange": "$$",
    "areaServed": ["Montreux", "Lausanne", "Vaud", "Switzerland"]
  };

  return (
    <Helmet htmlAttributes={{ lang: locale }}>
      <title>{currentTitle}</title>
      <meta name="description" content={currentDescription} />
      <meta name="keywords" content={keywords} />

      {/* OpenGraph / Facebook */}
      <meta property="og:type" content="website" />
      <meta property="og:url" content={url} />
      <meta property="og:title" content={currentTitle} />
      <meta property="og:description" content={currentDescription} />
      <meta property="og:image" content="https://pilot-ai.studio/og-image.jpg" />

      {/* Twitter */}
      <meta property="twitter:card" content="summary_large_image" />
      <meta property="twitter:url" content={url} />
      <meta property="twitter:title" content={currentTitle} />
      <meta property="twitter:description" content={currentDescription} />
      <meta property="twitter:image" content="https://pilot-ai.studio/og-image.jpg" />

      {/* Schema Markup */}
      <script type="application/ld+json">
        {JSON.stringify(schemaMarkup)}
      </script>
    </Helmet>
  );
};
