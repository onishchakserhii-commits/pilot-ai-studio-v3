import { motion } from 'framer-motion';
import { ScrollReveal } from './ScrollReveal';
import { useLanguage } from '../context/LanguageContext';

export const AIEmployeesSection = () => {
  const { t } = useLanguage();

  return (
    <ScrollReveal>
      <section className="max-w-7xl mx-auto px-6 mb-32 relative z-10 w-full">
        <div className="flex flex-col items-center mb-16 text-center">
          <h2 className="text-4xl md:text-5xl font-medium tracking-tight mb-6">{t.aiEmployees.title}</h2>
          <p className="text-xl text-gray-400 max-w-2xl font-light">{t.aiEmployees.subtitle}</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {t.aiEmployees.roles.map((agent, i) => (
            <motion.div 
              key={agent.title} 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              className="glass-panel glass-panel-hover p-8 rounded-2xl group flex flex-col justify-between min-h-[160px]"
            >
              <div>
                <div className="font-mono text-xs text-indigo-400/70 mb-4">0{i + 1} // AGENT</div>
                <h4 className="font-medium text-lg text-white mb-2 group-hover:text-indigo-200 transition-colors">{agent.title}</h4>
              </div>
              <p className="text-gray-500 text-sm font-light mt-4">{agent.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </ScrollReveal>
  );
};
