import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Type } from "@google/genai";
import { useLanguage } from '../context/LanguageContext';
import { useSettings } from '../context/SettingsContext';
import { ScrollReveal } from './ScrollReveal';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Key } from 'lucide-react';

export const AIDemo = () => {
  const { t } = useLanguage();
  const { settings } = useSettings();
  const [businessType, setBusinessType] = useState('');
  const [problem, setProblem] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const generateBlueprint = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!businessType || !problem) return;

    const apiKey = settings.geminiKey || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      setError('API Key is missing. Please click the settings icon in the navigation bar to provide your Gemini API Key.');
      return;
    }

    setLoading(true);
    setResult(null);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Generate an AI Business System blueprint for a ${businessType} facing the problem: ${problem}.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              automations: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "List of 3 recommended automations"
              },
              agents: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "List of 2-3 AI agents needed"
              },
              workflow: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Step-by-step workflow (4 steps)"
              }
            },
            required: ["automations", "agents", "workflow"]
          }
        }
      });

      if (response.text) {
        setResult(JSON.parse(response.text));
      }
    } catch (error) {
      console.error("AI Generation Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollReveal>
      <section className="max-w-7xl mx-auto px-6 mb-32 relative z-10 w-full">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-medium tracking-tight mb-6">{t.aiDemo.title}</h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto font-light">{t.aiDemo.subtitle}</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Input Form */}
          <div className="glass-panel p-8 md:p-10 rounded-[2rem] border border-white/5 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 group-hover:bg-indigo-500/10 transition-colors blur-[80px]" />
            <form onSubmit={generateBlueprint} className="space-y-6 relative z-10">
              <div className="space-y-2">
                <label className="text-xs font-mono text-gray-400 uppercase tracking-widest">Business Type</label>
                <Input 
                  value={businessType}
                  onChange={(e) => setBusinessType(e.target.value)}
                  placeholder={t.aiDemo.placeholderType}
                  className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-6 font-light h-14"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-mono text-gray-400 uppercase tracking-widest">Challenge</label>
                <Input 
                  value={problem}
                  onChange={(e) => setProblem(e.target.value)}
                  placeholder={t.aiDemo.placeholderProblem}
                  className="bg-white/5 border-white/10 focus:border-indigo-500 rounded-xl px-4 py-6 font-light h-14"
                />
              </div>
              <Button 
                disabled={loading || !businessType || !problem}
                className="w-full bg-white text-black hover:bg-gray-200 hover:scale-[1.02] transition-all rounded-xl py-6 font-medium tracking-wide uppercase text-sm shadow-[0_0_20px_rgba(255,255,255,0.1)] h-14"
              >
                {loading ? t.aiDemo.thinking : t.aiDemo.button}
              </Button>
            </form>
            
            <AnimatePresence>
              {error && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-light flex gap-3 items-center"
                >
                  <Key size={14} className="shrink-0" />
                  <p>{error}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* AI Result */}
          <div className="min-h-[400px] flex flex-col">
            <AnimatePresence mode="wait">
              {!result && !loading && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full flex flex-col items-center justify-center text-center p-8 border border-dashed border-white/10 rounded-[2rem]"
                >
                  <div className="text-4xl mb-4 opacity-20 italic">Waiting for input...</div>
                  <p className="text-gray-500 font-light text-sm">Fill the form to generate your custom AI strategy.</p>
                </motion.div>
              )}

              {loading && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full flex flex-col items-center justify-center p-8 text-center"
                >
                  <div className="w-12 h-12 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin mb-6" />
                  <div className="font-mono text-xs tracking-widest text-indigo-400 uppercase animate-pulse">{t.aiDemo.thinking}</div>
                </motion.div>
              )}

              {result && (
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-8"
                >
                  <div className="flex items-center gap-4 mb-2">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    <h3 className="text-xl font-medium text-white">{t.aiDemo.resultTitle}</h3>
                  </div>

                  <div className="grid gap-6">
                    <div className="glass-panel p-6 rounded-2xl border border-white/5">
                      <h4 className="text-xs font-mono text-indigo-400 uppercase tracking-widest mb-4">{t.aiDemo.labels.automationTitle}</h4>
                      <ul className="space-y-3">
                        {result.automations.map((item: string, i: number) => (
                          <li key={i} className="text-sm text-gray-300 font-light flex items-start">
                            <span className="text-indigo-500 mr-3">→</span>
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="glass-panel p-6 rounded-2xl border border-white/5">
                      <h4 className="text-xs font-mono text-indigo-400 uppercase tracking-widest mb-4">{t.aiDemo.labels.agentsTitle}</h4>
                      <div className="flex flex-wrap gap-2">
                        {result.agents.map((item: string, i: number) => (
                          <span key={i} className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-full text-xs text-gray-300 font-light">
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="glass-panel p-6 rounded-2xl border border-white/5">
                      <h4 className="text-xs font-mono text-indigo-400 uppercase tracking-widest mb-4">{t.aiDemo.labels.workflowTitle}</h4>
                      <div className="space-y-4">
                        {result.workflow.map((item: string, i: number) => (
                          <div key={i} className="flex items-center gap-4 group">
                             <div className="w-6 h-6 rounded-full border border-white/10 flex items-center justify-center text-[10px] font-mono text-gray-500 group-hover:border-indigo-500 group-hover:text-indigo-400 transition-colors">{i+1}</div>
                             <div className="text-sm text-gray-400 font-light">{item}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </section>
    </ScrollReveal>
  );
};
