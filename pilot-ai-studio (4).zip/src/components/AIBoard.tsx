import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

const activities = [
  { id: 1, text: "AGENT [RECEPTIONIST]: Booking processed for Swiss Dental", status: "success" },
  { id: 2, text: "AGENT [SALES]: New lead qualified via WhatsApp", status: "lead" },
  { id: 3, text: "AGENT [SUPPORT]: Inquiry from Geneva office resolved", status: "success" },
  { id: 4, text: "AGENT [BOOKING]: Syncing with owner's calendar...", status: "process" },
  { id: 5, text: "AGENT [FOLLOW-UP]: Automatic follow-up sent to +41 79...", status: "success" },
  { id: 6, text: "AGENT [ANALYSIS]: Generating SEO audit for Nexus Corp", status: "process" },
];

export const AIBoard = () => {
  const [currentActivities, setCurrentActivities] = useState<typeof activities>([]);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % activities.length);
      setCurrentActivities((prev) => {
        const next = activities[index];
        const newArr = [next, ...prev].slice(0, 3);
        return newArr;
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [index]);

  return (
    <div className="w-full max-w-lg mx-auto h-[240px] relative overflow-hidden flex flex-col items-center justify-center font-mono pointer-events-none">
      <div className="absolute inset-0 bg-indigo-500/5 blur-[100px] rounded-full" />
      
      {/* Workflow nodes imitation */}
      <div className="flex gap-12 mb-12 relative">
          <motion.div 
            animate={{ scale: [1, 1.1, 1] }} 
            transition={{ repeat: Infinity, duration: 2 }}
            className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-xl"
          >
            🤖
          </motion.div>
          <div className="w-24 h-[1px] bg-gradient-to-r from-indigo-500/50 to-transparent mt-6 relative">
             <motion.div 
               animate={{ x: [0, 96] }} 
               transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
               className="absolute top-0 w-2 h-full bg-indigo-400 blur-[2px]"
             />
          </div>
          <motion.div 
            animate={{ scale: [1, 1.05, 1] }} 
            transition={{ repeat: Infinity, duration: 2.5 }}
            className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-xl"
          >
            ⚙️
          </motion.div>
      </div>

      <div className="space-y-3 w-full text-left px-4">
        <AnimatePresence>
          {currentActivities.map((activity, i) => (
            <motion.div
              key={`${activity.id}-${index}-${i}`}
              initial={{ opacity: 0, y: 10, filter: "blur(4px)" }}
              animate={{ opacity: 1 - i * 0.3, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex items-center gap-4 text-[10px] tracking-tight uppercase"
            >
              <div className={`w-1.5 h-1.5 rounded-full ${
                activity.status === 'success' ? 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]' : 
                activity.status === 'lead' ? 'bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]' : 
                'bg-yellow-500 animate-pulse'
              }`} />
              <span className="text-gray-400/80">{activity.text}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* AI Thinking Line */}
      <div className="mt-8 flex items-center gap-3">
         <div className="h-[1px] w-24 bg-indigo-500/20" />
         <div className="text-[9px] text-indigo-400/60 font-mono tracking-widest uppercase animate-pulse">Running Background Workers</div>
         <div className="h-[1px] w-24 bg-indigo-500/20" />
      </div>
    </div>
  );
};
