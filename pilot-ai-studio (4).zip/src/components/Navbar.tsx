import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { Locale } from '../locales/types';
import { Menu, X, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { SettingsModal } from './SettingsModal';

export const Navbar = () => {
  const { locale, setLocale, t } = useLanguage();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Automation', path: '/automation' },
    { name: 'Audit', path: '/audit' },
    { name: 'Portfolio', path: '/portfolio' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <header className="fixed top-0 w-full z-50 border-b border-white/5 bg-background/50 backdrop-blur-xl text-white">
      <nav className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <Link to="/" className="text-sm font-mono tracking-widest uppercase hover:text-indigo-300 transition-colors z-50">Pilot Ai <span className="opacity-50">//</span> Studio</Link>
        <div className="hidden md:flex gap-10 text-xs font-mono tracking-widest uppercase text-gray-500">
          {navLinks.map((link) => (
            <Link key={link.name} to={link.path} className="hover:text-white transition-colors">{link.name}</Link>
          ))}
        </div>
        <div className="flex gap-4 sm:gap-6 items-center z-50">
          <button 
            className="p-2 text-gray-400 hover:text-indigo-400 transition-colors"
            onClick={() => setIsSettingsOpen(true)}
          >
            <Settings size={18} />
          </button>
          <button 
            className="text-xs font-mono tracking-widest text-gray-400 hover:text-white transition-colors"
            onClick={() => {
              const locales: Locale[] = ['fr', 'en', 'ua'];
              const currentIndex = locales.indexOf(locale);
              setLocale(locales[(currentIndex + 1) % locales.length]);
            }}
          >
            [{locale.toUpperCase()}]
          </button>
          <a href="https://wa.me/41796186852" target="_blank" rel="noopener noreferrer" className="text-xs font-mono tracking-widest hover:text-green-400 transition-colors hidden sm:block">WHATSAPP</a>
          <Link to="/audit" className="hidden sm:block bg-white text-background px-6 py-2.5 rounded-full font-medium text-xs tracking-wider uppercase hover:bg-gray-200 transition-colors shadow-[0_0_15px_rgba(255,255,255,0.1)] hover:shadow-[0_0_25px_rgba(255,255,255,0.2)]">
            Free Audit
          </Link>
          <button 
            className="md:hidden p-2 text-gray-400 hover:text-white transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="absolute top-20 left-0 w-full bg-background/95 backdrop-blur-3xl border-b border-white/5 md:hidden"
          >
            <div className="flex flex-col px-6 py-8 gap-6">
              {navLinks.map((link) => (
                <Link 
                  key={link.name} 
                  to={link.path} 
                  className="text-lg font-mono tracking-widest hover:text-indigo-300 transition-colors"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                </Link>
              ))}
              <div className="h-px w-full bg-white/10 my-2" />
              <Link 
                to="/audit" 
                className="bg-white text-background py-4 rounded-xl font-medium text-center tracking-wider hover:bg-gray-200 transition-colors mt-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                FREE AI AUDIT
              </Link>
              <a 
                 href="https://wa.me/41796186852" 
                 target="_blank" 
                 rel="noopener noreferrer" 
                 className="flex justify-center items-center gap-2 border border-white/20 py-4 rounded-xl font-medium tracking-wider hover:bg-white/5 transition-colors"
              >
                 WHATSAPP CONSULTATION
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
    </header>
  );
};
