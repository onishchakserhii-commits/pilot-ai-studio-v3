import { motion } from 'framer-motion';
import { ScrollReveal } from './ScrollReveal';
import { useLanguage } from '../context/LanguageContext';

export const SystemArchitecture = () => {
  const { t } = useLanguage();

  const techStack = [
    { name: "OpenAI", role: "Intelligence", icon: "🧠" },
    { name: "n8n", role: "Orchestration", icon: "⚙️" },
    { name: "Vercel", role: "Infrastructure", icon: "▲" },
    { name: "Supabase", role: "Memory", icon: "💾" },
    { name: "WhatsApp", role: "Communication", icon: "💬" }
  ];

  return (
    <ScrollReveal>
      <section className="max-w-7xl mx-auto px-6 mb-32 relative z-10 w-full">
        <h2 className="text-4xl md:text-5xl font-medium mb-16 tracking-tight text-center">{t.architecture.title}</h2>
        <div className="animated-glow-border p-1 md:p-12 rounded-[2.5rem] relative overflow-hidden">
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/10 rounded-full blur-[100px] pointer-events-none" />
           <div className="bg-black/60 backdrop-blur-3xl rounded-[2rem] border border-white/5 p-8 md:p-12 relative z-10">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
                {techStack.map((tech, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="flex flex-col items-center text-center p-6 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 hover:border-white/20 transition-all cursor-default"
                  >
                     <div className="text-3xl mb-4 grayscale opacity-80">{tech.icon}</div>
                     <div className="font-medium text-white mb-1">{tech.name}</div>
                     <div className="text-xs font-mono text-indigo-400 tracking-widest uppercase">{tech.role}</div>
                  </motion.div>
                ))}
              </div>
           </div>
        </div>
      </section>
    </ScrollReveal>
  );
};
