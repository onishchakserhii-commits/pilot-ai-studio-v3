import { motion } from 'framer-motion';
import { ScrollReveal } from './ScrollReveal';
import { useLanguage } from '../context/LanguageContext';

export const AutonomousWorkflows = () => {
  const { t } = useLanguage();

  return (
    <ScrollReveal>
      <section className="max-w-7xl mx-auto px-6 mb-32 relative z-10 w-full">
        <h2 className="text-4xl md:text-5xl font-medium mb-16 text-center tracking-tight">{t.aiWorkflows.title}</h2>
        <div className="space-y-6">
          {t.aiWorkflows.items.map((workflow, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="glass-panel p-8 md:p-10 rounded-3xl group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 group-hover:bg-indigo-500/10 transition-colors blur-[80px]" />
              <h3 className="text-xl md:text-2xl font-medium mb-8 text-white relative z-10">{workflow.title}</h3>
              <div className="flex flex-wrap items-center gap-3 relative z-10">
                {workflow.flow.split('→').map((step, j, arr) => (
                  <div key={j} className="flex items-center gap-3">
                    <span className="px-5 py-3 rounded-xl bg-white/5 border border-white/10 text-gray-300 text-sm font-light whitespace-normal min-w-[max-content] group-hover:border-indigo-500/30 transition-colors">
                      {step.trim()}
                    </span>
                    {j < arr.length - 1 && (
                      <span className="text-indigo-400/50 font-medium text-lg">→</span>
                    )}
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </ScrollReveal>
  );
};
