import { motion } from 'framer-motion';
import { LeadForm } from '../components/LeadForm';
import { useLanguage } from '../context/LanguageContext';
import { CheckCircle } from 'lucide-react';
import { ScrollReveal } from '../components/ScrollReveal';
import { TypewriterText } from '../components/TypewriterText';
import { SEO } from '../components/SEO';

export const Audit = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen text-white pt-20 relative">
      <SEO 
        title="Free AI Audit & Validation | Pilot AI Studio" 
        description="Get a free AI audit to find automation opportunities in your Swiss business."
        url="https://pilot-ai.studio/audit"
      />
      <div className="fixed inset-0 bg-grid-dots pointer-events-none opacity-20" />
      <div className="max-w-4xl mx-auto px-6 py-20 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="text-center mb-16"
        >
          <div className="inline-block px-4 py-2 border border-white/10 rounded-full bg-white/5 backdrop-blur-md mb-8 font-mono text-xs tracking-wider text-indigo-300">
             <TypewriterText text="// INTELLIGENT SYSTEM ANALYSIS" delay={0.2} />
          </div>
          <h1 className="text-6xl md:text-8xl font-medium mb-6 tracking-tighter text-gradient pb-2">{t.auditPage.title}</h1>
          <p className="text-xl md:text-2xl text-gray-400 font-light">{t.auditPage.explanation}</p>
        </motion.div>

        <ScrollReveal>
          <div className="glass-panel p-12 rounded-3xl mb-16 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-[80px]" />
            <h2 className="text-2xl font-mono text-indigo-400/80 mb-8 tracking-widest uppercase">What you get</h2>
            <p className="text-gray-300 mb-10 font-light text-lg">{t.auditPage.whatClientGets}</p>
            <div className="grid gap-6">
              {t.auditPage.examples.map((example, i) => (
                <motion.div 
                  key={i} 
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex items-center text-gray-300 font-light bg-white/5 p-4 rounded-xl border border-white/5"
                >
                  <CheckCircle className="w-5 h-5 text-indigo-400 mr-4 shrink-0" />
                  {example}
                </motion.div>
              ))}
            </div>
          </div>
        </ScrollReveal>

        <ScrollReveal>
          <section id="audit-form" className="glass-panel p-12 rounded-3xl">
            <h2 className="text-3xl font-medium mb-10 text-center tracking-tight">{t.auditPage.formTitle}</h2>
            <LeadForm />
          </section>
        </ScrollReveal>
      </div>
    </div>
  );
};
