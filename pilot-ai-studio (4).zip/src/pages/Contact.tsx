import { motion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import { Mail, MessageCircle, CalendarClock, Globe, Clock, Send } from 'lucide-react';
import { LeadForm } from '../components/LeadForm';
import { ScrollReveal } from '../components/ScrollReveal';
import { TypewriterText } from '../components/TypewriterText';
import { SEO } from '../components/SEO';

export const Contact = () => {
  const { t } = useLanguage();

  const methods = [
    {
      icon: MessageCircle,
      title: t.contactPage.methods.whatsapp,
      url: "https://wa.me/41796186852",
      color: "text-green-500",
      bgHover: "hover:bg-green-500/10",
      borderHover: "hover:border-green-500/30"
    },
    {
      icon: Send,
      title: t.contactPage.methods.telegram,
      url: "https://t.me/yourusername", // Replace with real string
      color: "text-blue-400",
      bgHover: "hover:bg-blue-400/10",
      borderHover: "hover:border-blue-400/30"
    },
    {
      icon: Mail,
      title: t.contactPage.methods.email,
      url: "mailto:hello@pilotaistudio.com",
      color: "text-indigo-400",
      bgHover: "hover:bg-indigo-400/10",
      borderHover: "hover:border-indigo-400/30"
    }
  ];

  return (
    <div className="min-h-screen text-white pt-20 relative">
      <SEO 
        title="Contact Pilot AI Studio | Let's Talk AI & Automation in Switzerland" 
        description="Ready to transform your business with AI? Contact Pilot AI Studio in Vaud, Switzerland for custom web development and n8n automation."
        url="https://pilot-ai.studio/contact"
      />
      <div className="fixed inset-0 bg-grid-dots pointer-events-none opacity-20" />
      <div className="max-w-7xl mx-auto px-6 py-20 relative z-10">
        <ScrollReveal duration={0.7} yOffset={30}>
          <div className="text-center mb-20">
            <div className="inline-block px-4 py-2 border border-white/10 rounded-full bg-white/5 backdrop-blur-md mb-8 font-mono text-xs tracking-wider text-indigo-300">
               <TypewriterText text="// INITIATE COMMUNICATION PROTOCOL" delay={0.2} />
            </div>
            <h1 className="text-6xl md:text-8xl font-medium mb-6 tracking-tighter text-gradient">{t.contactPage.title}</h1>
            <p className="text-xl md:text-2xl text-gray-400 font-light">{t.contactPage.subtitle}</p>
          </div>
        </ScrollReveal>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left Column: Info & Links */}
          <div className="space-y-12">
            <div className="grid sm:grid-cols-2 gap-6">
              {methods.map((method, i) => (
                <div key={i} className="h-full">
                  <ScrollReveal delay={i * 0.1}>
                    <a 
                      href={method.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`glass-panel p-8 rounded-3xl group flex flex-col items-center justify-center text-center h-full ${method.bgHover} ${method.borderHover}`}
                    >
                      <method.icon className={`w-8 h-8 mb-6 ${method.color} group-hover:scale-110 transition-transform`} />
                      <span className="font-light text-gray-300 group-hover:text-white transition-colors">{method.title}</span>
                    </a>
                  </ScrollReveal>
                </div>
              ))}
              
              <ScrollReveal delay={methods.length * 0.1}>
                <a 
                  href="https://calendly.com/your-calendar" // Replace with real string
                  target="_blank"
                  rel="noopener noreferrer"
                  className="glass-panel p-8 rounded-3xl transition duration-500 group flex flex-col items-center justify-center text-center h-full hover:bg-orange-500/10 hover:border-orange-500/30"
                >
                  <CalendarClock className="w-8 h-8 mb-6 text-orange-400 group-hover:scale-110 transition-transform" />
                  <span className="font-light text-gray-300 group-hover:text-white transition-colors">{t.contactPage.calendlyTitle}</span>
                </a>
              </ScrollReveal>
            </div>

            <ScrollReveal>
              <div className="flex flex-col gap-8 glass-panel p-10 rounded-3xl">
                <div className="flex items-start gap-5 text-gray-300">
                  <div className="bg-indigo-500/10 p-4 rounded-2xl border border-indigo-500/20">
                    <Clock className="w-6 h-6 text-indigo-400" />
                  </div>
                  <div>
                    <h3 className="font-medium text-white mb-2 tracking-wide">Quick Response Promise</h3>
                    <p className="text-sm font-light text-gray-400 leading-relaxed">{t.contactPage.responsePromise}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-5 text-gray-300">
                  <div className="bg-indigo-500/10 p-4 rounded-2xl border border-indigo-500/20">
                    <Globe className="w-6 h-6 text-indigo-400" />
                  </div>
                  <div>
                    <h3 className="font-medium text-white mb-2 tracking-wide">Global Coverage</h3>
                    <p className="text-sm font-light text-gray-400 leading-relaxed">{t.contactPage.workingRegions}</p>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          </div>

          {/* Right Column: Form */}
          <ScrollReveal delay={0.2} className="h-full">
            <div className="bg-background/80 backdrop-blur-xl p-12 rounded-3xl border border-white/10 relative overflow-hidden shadow-2xl h-full">
              <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/5 blur-[120px] rounded-full pointer-events-none" />
              
              <h2 className="text-3xl font-medium mb-10 relative z-10 tracking-tight">{t.contactPage.formTitle}</h2>
              <div className="relative z-10">
                <LeadForm />
              </div>
            </div>
          </ScrollReveal>
        </div>

        {/* Google Maps Location */}
        <ScrollReveal delay={0.4}>
          <div className="mt-20 w-full h-[400px] rounded-3xl overflow-hidden glass-panel border border-white/10 relative">
             <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d87878.71182379517!2d6.862283083626244!3d46.43573850785125!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478e5352671b5bb5%3A0x673db2f7cf513f56!2sMontreux%2C%20Switzerland!5e0!3m2!1sen!2sus!4v1700000000000!5m2!1sen!2sus" 
                width="100%" 
                height="100%" 
                style={{ border: 0, filter: "invert(90%) hue-rotate(180deg) opacity(0.8)" }} 
                allowFullScreen={false} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
             ></iframe>
             <div className="absolute top-6 left-6 glass-panel px-6 py-4 rounded-2xl bg-black/50 backdrop-blur-md">
                <p className="font-medium text-white text-lg">Pilot AI Studio</p>
                <p className="text-gray-400 font-light text-sm mt-1">Montreux, Vaud <br />Switzerland</p>
             </div>
          </div>
        </ScrollReveal>

      </div>
    </div>
  );
};
