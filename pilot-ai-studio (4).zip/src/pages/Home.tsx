import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { AIEmployeesSection } from '../components/AIEmployeesSection';
import { AutonomousWorkflows } from '../components/AutonomousWorkflows';
import { PricingPackages } from '../components/PricingPackages';
import { SystemArchitecture } from '../components/SystemArchitecture';
import { AIDemo } from '../components/AIDemo';
import { LeadForm } from '../components/LeadForm';
import { Accordion } from '../components/Accordion';
import { useLanguage } from '../context/LanguageContext';
import { ScrollReveal } from '../components/ScrollReveal';
import { TypewriterText } from '../components/TypewriterText';
import { SEO } from '../components/SEO';

export const Home = () => {
  const { locale, setLocale, t } = useLanguage();

  return (
    <div className="min-h-screen text-white content-grid">
      <SEO />
      <div className="fixed inset-0 bg-grid-dots pointer-events-none opacity-20" />
      <main className="pt-32 pb-20 overflow-hidden relative z-10">
        {/* Hero */}
        <section className="max-w-7xl mx-auto px-6 mb-32 relative text-center">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-500/20 rounded-full blur-[120px] -z-10" />
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="inline-block px-4 py-2 border border-white/10 rounded-full bg-white/5 backdrop-blur-md mb-8 font-mono text-xs tracking-wider text-indigo-300"
          >
            <TypewriterText text="PILOT AI STUDIO // GEN-AI WEBSITES & AUTOMATIONS" delay={0.2} />
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="text-6xl md:text-8xl lg:text-[7rem] font-medium tracking-tighter leading-[0.9] mb-10 text-white"
          >
            {t.hero.titlePart1} <br className="hidden md:block" /> <span className="text-gradient font-bold italic">{t.hero.titlePart2}</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto mb-12 font-light"
          >
            {t.hero.subtitle}
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col sm:flex-row gap-4 justify-center w-full max-w-md mx-auto sm:max-w-none mb-16"
          >
            <a href="#contact" className="w-full sm:w-auto bg-white text-black px-10 py-5 rounded-full font-medium tracking-wide hover:scale-105 transition shadow-[0_0_40px_rgba(255,255,255,0.15)] text-center text-sm uppercase">
              {t.hero.ctaWebsite}
            </a>
            <a href="https://wa.me/41796186852" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto border border-white/20 px-10 py-5 rounded-full font-medium tracking-wide hover:bg-white/5 transition backdrop-blur-sm text-center text-sm uppercase">
              {t.hero.ctaWhatsApp}
            </a>
          </motion.div>

        </section>

        {/* AI Employees & Workflows */}
        <AIEmployeesSection />
        <AutonomousWorkflows />

        {/* AI Demo */}
        <AIDemo />

        {/* Industries */}
        <ScrollReveal>
          <section id="industries" className="max-w-7xl mx-auto px-6 mb-32 relative z-10">
            <h2 className="text-4xl md:text-5xl font-medium mb-16 text-center tracking-tight">{t.industries.title}</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {t.industries.items.map((item, i) => (
                <motion.div 
                  key={item.slug} 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                >
                  <Link 
                    to={`/industry/${item.slug}`}
                    className="glass-panel glass-panel-hover p-8 rounded-2xl h-full flex flex-col block group hover:border-indigo-500/40 transition-all"
                  >
                    <h4 className="font-medium text-lg mb-4 text-white group-hover:text-indigo-300 transition-colors flex justify-between items-center">
                      {item.name}
                      <span className="text-xs font-mono text-indigo-500/0 group-hover:text-indigo-500/80 transition-all">VIEW →</span>
                    </h4>
                    <p className="text-gray-500 text-sm font-light leading-relaxed flex-1">
                      {item.painPoint} 
                      <span className="block text-indigo-400/60 mt-3 pt-3 border-t border-white/5 italic">
                        {item.solution}
                      </span>
                    </p>
                  </Link>
                </motion.div>
              ))}
            </div>
          </section>
        </ScrollReveal>

        {/* Portfolio / Cases */}
        <ScrollReveal>
          <section className="max-w-7xl mx-auto px-6 mb-32 relative z-10">
            <h2 className="text-4xl md:text-5xl font-medium mb-16 tracking-tight">{t.portfolio.title}</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {t.portfolio.items.map((item, i) => (
                <motion.div 
                  key={item.name} 
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: i * 0.1 }}
                  className="glass-panel glass-panel-hover p-10 rounded-3xl group"
                >
                  <h3 className="text-2xl font-medium mb-6 text-white">{item.name}</h3>
                  <div className="space-y-4 text-sm font-light text-gray-400">
                    <p className="flex justify-between border-b border-white/5 pb-2"><span className="text-gray-500 uppercase tracking-widest font-mono text-xs">Result</span> <span className="text-white">{item.result}</span></p>
                    <p className="flex justify-between border-b border-white/5 pb-2"><span className="text-gray-500 uppercase tracking-widest font-mono text-xs">Automation</span> <span className="text-white">{item.automation}</span></p>
                    <p className="flex justify-between border-b border-white/5 pb-2"><span className="text-gray-500 uppercase tracking-widest font-mono text-xs">Speed</span> <span className="text-white">{item.speed}</span></p>
                    <p className="flex justify-between pb-2"><span className="text-gray-500 uppercase tracking-widest font-mono text-xs">Conversion</span> <span className="text-indigo-300 font-medium">{item.conversion}</span></p>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        </ScrollReveal>

        {/* Before / After */}
        <ScrollReveal>
          <section className="py-20 mb-32 max-w-7xl mx-auto px-6 relative z-10">
            <h2 className="text-4xl md:text-5xl font-medium mb-16 text-center tracking-tight text-white">{t.beforeAfter.title}</h2>
            <div className="grid md:grid-cols-2 gap-8 items-stretch">
              <motion.div 
                initial={{ x: -30, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                viewport={{ once: true }}
                className="glass-panel hover:border-red-500/20 transition-colors p-10 rounded-3xl relative overflow-hidden group"
              >
                  <div className="absolute top-0 right-0 w-48 h-48 bg-red-500/5 group-hover:bg-red-500/10 transition-colors blur-[80px]" />
                  <h3 className="text-xl font-mono mb-10 text-red-400/80 uppercase tracking-widest">{t.beforeAfter.before.title}</h3>
                  <ul className="space-y-6 text-gray-400 font-light relative z-10">
                      {t.beforeAfter.before.items.map((item, i) => (
                        <li key={i} className="flex items-start">
                          <span className="text-red-500/50 mr-4 font-mono">0{i+1}</span>
                          {item}
                        </li>
                      ))}
                  </ul>
              </motion.div>
              <motion.div 
                initial={{ x: 30, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                viewport={{ once: true }}
                className="glass-panel hover:border-indigo-500/30 transition-colors p-10 rounded-3xl relative overflow-hidden group"
              >
                  <div className="absolute top-0 left-0 w-48 h-48 bg-indigo-500/5 group-hover:bg-indigo-500/15 transition-colors blur-[80px]" />
                  <h3 className="text-xl font-mono mb-10 text-indigo-400/80 uppercase tracking-widest">{t.beforeAfter.after.title}</h3>
                  <ul className="space-y-6 text-gray-300 font-light relative z-10">
                      {t.beforeAfter.after.items.map((item, i) => (
                        <li key={i} className="flex items-start">
                          <span className="text-indigo-400 mr-4 font-mono">0{i+1}</span>
                          {item}
                        </li>
                      ))}
                  </ul>
              </motion.div>
            </div>
          </section>
        </ScrollReveal>

        {/* Testimonials */}
        <ScrollReveal>
          <section className="py-20 mb-32 max-w-7xl mx-auto px-6 relative z-10">
            <h2 className="text-4xl md:text-5xl font-medium mb-16 text-center tracking-tight">{t.testimonials.title}</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {t.testimonials.items.map((item, i) => (
                <motion.div 
                  key={i} 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="glass-panel p-10 rounded-3xl relative group"
                >
                  <p className="text-gray-400 font-light italic mb-8 leading-relaxed">"{item.quote}"</p>
                  <div>
                    <p className="font-medium text-white">{item.name}</p>
                    <p className="text-indigo-400 font-mono text-xs mt-1 uppercase tracking-widest">{item.role}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        </ScrollReveal>

        {/* AI Architecture & Pricing */}
        <SystemArchitecture />
        <PricingPackages />

        {/* Process */}
        <ScrollReveal>
          <section className="max-w-7xl mx-auto px-6 mb-32 relative z-10">
            <h2 className="text-4xl md:text-5xl font-medium mb-16 tracking-tight">{t.process.title}</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {t.process.items.map((step, i) => (
                <motion.div 
                  key={i} 
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15 }}
                  className="border-t border-white/10 pt-8 group cursor-default"
                >
                  <span className="text-indigo-400/50 font-mono text-sm tracking-widest group-hover:text-indigo-400 transition-colors">0{i+1} //</span>
                  <h3 className="text-xl font-medium mt-4 text-gray-300 group-hover:text-white transition-colors">{step}</h3>
                </motion.div>
              ))}
            </div>
          </section>
        </ScrollReveal>

        {/* FAQ */}
        <ScrollReveal>
          <section className="max-w-3xl mx-auto px-6 mb-32 relative z-10">
            <h2 className="text-4xl md:text-5xl font-medium mb-16 text-center tracking-tight">{t.faq.title}</h2>
            <Accordion items={t.faq.items} />
          </section>
        </ScrollReveal>

        {/* Free AI Audit Form Section */}
        <ScrollReveal>
          <section id="contact" className="max-w-4xl mx-auto px-6 mb-32 relative z-10">
            <div className="animated-glow-border p-12 rounded-[2.5rem]">
              <h2 className="text-3xl font-medium mb-4 text-center tracking-tight">{t.audit.title}</h2>
              <p className="text-gray-400 font-light mb-10 text-center">{t.audit.description}</p>
              <LeadForm />
            </div>
          </section>
        </ScrollReveal>

        {/* Final CTA */}
        <ScrollReveal>
          <section className="animated-glow-border py-24 text-center rounded-[3rem] max-w-7xl mx-auto px-6 mb-20 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/10 via-transparent to-transparent opacity-50" />
            <h2 className="text-5xl md:text-7xl font-medium tracking-tighter mb-6 relative z-10 text-white">{t.finalCTA.title}</h2>
            <p className="text-xl md:text-2xl mb-12 text-gray-400 font-light relative z-10">{t.finalCTA.subtitle}</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 relative z-10 w-full max-w-md mx-auto sm:max-w-none">
              <a href="#contact" className="w-full sm:w-auto bg-white text-background px-10 py-5 rounded-full font-medium uppercase tracking-widest text-xs hover:bg-gray-200 transition-colors text-center shadow-[0_0_30px_rgba(255,255,255,0.2)] hover:shadow-[0_0_50px_rgba(255,255,255,0.3)]">
                {t.finalCTA.ctaWebsite}
              </a>
              <a href="https://wa.me/41796186852" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto glass-panel px-10 py-5 rounded-full font-medium uppercase tracking-widest text-xs hover:bg-white/10 transition-colors text-center text-white">
                {t.finalCTA.ctaWhatsApp}
              </a>
            </div>
          </section>
        </ScrollReveal>
      </main>

      <footer className="border-t border-white/10 py-10">
        <div className="max-w-7xl mx-auto px-6 text-center text-gray-500 text-sm">
          © {new Date().getFullYear()} Pilot Ai Studio. All rights reserved.
        </div>
      </footer>
    </div>
  );
};
