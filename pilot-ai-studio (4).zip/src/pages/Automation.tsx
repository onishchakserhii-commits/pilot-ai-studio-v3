import { motion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import { ScrollReveal } from '../components/ScrollReveal';
import { TypewriterText } from '../components/TypewriterText';
import { SEO } from '../components/SEO';

export const Automation = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen text-white pt-20 relative">
      <SEO 
        title="AI Automation in Vaud & Switzerland | n8n Experts" 
        description="Streamline your operations with our AI automation and n8n expertise tailored for Swiss businesses."
        url="https://pilot-ai.studio/automation"
      />
      <div className="fixed inset-0 bg-grid-dots pointer-events-none opacity-20" />
      <div className="max-w-7xl mx-auto px-6 py-20 relative z-10">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="inline-block px-4 py-2 border border-white/10 rounded-full bg-white/5 backdrop-blur-md mb-8 font-mono text-xs tracking-wider text-indigo-300"
        >
          <TypewriterText text="// AUTOMATION SYSTEMS" delay={0.2} />
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-6xl md:text-8xl font-medium mb-6 tracking-tighter"
        >
          <span className="text-gradient font-bold italic">{t.automationPage.title}</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-xl md:text-2xl text-gray-400 mb-16 max-w-3xl font-light"
        >
          {t.automationPage.description}
        </motion.p>

        <ScrollReveal>
          <div className="grid md:grid-cols-3 gap-6 mb-24">
            <div className="glass-panel glass-panel-hover p-10 rounded-3xl">
              <h3 className="text-xl font-medium mb-4 text-white">{t.automationPage.sections.workflows}</h3>
              <p className="text-gray-400 font-light leading-relaxed">Implement robust, automated workflows tailored to your operational needs.</p>
            </div>
            <div className="glass-panel glass-panel-hover p-10 rounded-3xl">
              <h3 className="text-xl font-medium mb-4 text-white">{t.automationPage.sections.diagrams}</h3>
              <p className="text-gray-400 font-light leading-relaxed">Clear visual documentation of your automated business logic.</p>
            </div>
            <div className="glass-panel glass-panel-hover p-10 rounded-3xl">
              <h3 className="text-xl font-medium mb-4 text-white">{t.automationPage.sections.logic}</h3>
              <p className="text-gray-400 font-light leading-relaxed">Advanced automation logic to handle complex business scenarios.</p>
            </div>
          </div>
        </ScrollReveal>

        <ScrollReveal>
          <section className="bg-indigo-950/10 glass-panel p-12 rounded-3xl">
            <h2 className="text-2xl font-mono text-indigo-400/80 mb-10 tracking-widest uppercase">{t.automationPage.integrations.title}</h2>
            <div className="flex flex-wrap gap-4">
              {t.automationPage.integrations.items.map((integration, i) => (
                <motion.div 
                  key={i} 
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-white/5 border border-white/10 px-6 py-3 rounded-full text-sm font-light hover:bg-white/10 hover:border-indigo-500/50 transition cursor-default"
                >
                  {integration}
                </motion.div>
              ))}
            </div>
          </section>
        </ScrollReveal>
      </div>
    </div>
  );
};
