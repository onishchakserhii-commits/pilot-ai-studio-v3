import { motion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import { ScrollReveal } from '../components/ScrollReveal';
import { TypewriterText } from '../components/TypewriterText';
import { SEO } from '../components/SEO';

export const Portfolio = () => {
  const { t } = useLanguage();

  const projects = [
    {
      title: "Local Clinic Assistant",
      niche: "Healthcare",
      description: "AI Voice & Chat agent handling 100+ appointments daily. Reduced admin workload by 40%.",
      tags: ["AI Voice", "n8n", "Calendly"]
    },
    {
      title: "Real Estate Lead Gen",
      niche: "Real Estate",
      description: "Automated WhatsApp funnel connected to CRM. Captured and qualified 300% more leads.",
      tags: ["WhatsApp", "Supabase", "OpenAI"]
    },
    {
      title: "E-Commerce Restock System",
      niche: "Retail",
      description: "Automated inventory tracking and supplier notification via Google Sheets.",
      tags: ["Google Sheets", "Gmail", "Automation"]
    },
    {
      title: "B2B SaaS Onboarding",
      niche: "SaaS",
      description: "Custom built onboarding flow with AI personalization, cutting drop-offs by 60%.",
      tags: ["TypeScript", "Next.js", "GPT-4"]
    }
  ];

  return (
    <div className="min-h-screen text-white pt-20 relative">
      <SEO 
        title="Our Portfolio | Pilot AI Studio" 
        description="Explore our recent projects in AI web development and busines automation."
        url="https://pilot-ai.studio/portfolio"
      />
      <div className="fixed inset-0 bg-grid-dots pointer-events-none opacity-20" />
      <div className="max-w-7xl mx-auto px-6 py-20 relative z-10">
        <ScrollReveal duration={0.7} yOffset={30}>
          <div className="mb-16">
            <div className="inline-block px-3 py-1 border border-white/10 rounded-full bg-white/5 backdrop-blur-md mb-6 font-mono text-[10px] tracking-widest text-indigo-300 uppercase">
              <TypewriterText text="OUR WORK // SHOWCASE" delay={0.2} />
            </div>
            <h1 className="text-4xl md:text-6xl font-medium tracking-tight mb-6">
              Our <span className="text-gradient italic font-bold">Portfolio</span>
            </h1>
            <p className="text-xl text-gray-400 font-light max-w-2xl leading-relaxed">
              Real results for modern businesses. From intelligent websites to fully automated operational workflows.
            </p>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, i) => (
            <div key={project.title}>
              <ScrollReveal delay={i * 0.1}>
                <div className="glass-panel p-8 md:p-10 rounded-3xl h-full flex flex-col justify-between group hover:-translate-y-1 transition-transform duration-500">
                  <div>
                    <div className="text-xs font-mono tracking-widest text-indigo-400/80 mb-6 uppercase">[{project.niche}]</div>
                    <h3 className="text-2xl md:text-3xl font-medium mb-4 text-white group-hover:text-indigo-200 transition-colors">{project.title}</h3>
                    <p className="text-gray-400 font-light text-lg mb-8 leading-relaxed">
                      {project.description}
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    {project.tags.map((tag, j) => (
                      <span key={j} className="text-xs font-mono px-3 py-1.5 rounded-full border border-white/10 bg-white/5 text-gray-300">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </ScrollReveal>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
