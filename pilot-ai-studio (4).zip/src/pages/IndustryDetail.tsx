import { useParams, Link, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import { ScrollReveal } from '../components/ScrollReveal';
import { SEO } from '../components/SEO';
import { LeadForm } from '../components/LeadForm';

export const IndustryDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const { t } = useLanguage();

  if (!slug || !t.industryDetails[slug]) {
    return <Navigate to="/" replace />;
  }

  const detail = t.industryDetails[slug];

  return (
    <div className="min-h-screen text-white content-grid pb-20">
      <SEO title={`${detail.title} | Pilot Ai Studio`} description={detail.heroSubtitle} />
      <div className="fixed inset-0 bg-grid-dots pointer-events-none opacity-20" />
      
      <main className="pt-32 relative z-10">
        <section className="max-w-7xl mx-auto px-6 mb-32 text-center">
          <Link 
            to="/" 
            className="inline-flex items-center text-indigo-400 mb-12 hover:text-indigo-300 transition-colors font-mono text-sm tracking-widest uppercase"
          >
            ← Back to Navigation
          </Link>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-medium tracking-tighter mb-8"
          >
            {detail.heroTitle}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto font-light leading-relaxed"
          >
            {detail.heroSubtitle}
          </motion.p>
        </section>

        {/* Features Grid */}
        <ScrollReveal>
          <section className="max-w-7xl mx-auto px-6 mb-32">
            <h2 className="text-3xl md:text-4xl font-medium mb-16 text-center tracking-tight">Core AI Capabilities</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {detail.features.map((feature, i) => (
                <div key={i} className="glass-panel p-10 rounded-3xl group hover:border-indigo-500/30 transition-colors relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 blur-[50px]" />
                  <div className="font-mono text-xs text-indigo-400/60 mb-6 uppercase tracking-widest">Capability 0{i+1}</div>
                  <h3 className="text-xl font-medium mb-4 text-white">{feature.title}</h3>
                  <p className="text-gray-400 font-light text-sm leading-relaxed">{feature.desc}</p>
                </div>
              ))}
            </div>
          </section>
        </ScrollReveal>

        {/* Agents & Benefits */}
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 mb-32 items-start">
           <ScrollReveal>
             <div className="glass-panel p-10 md:p-12 rounded-[2.5rem] relative overflow-hidden">
                <div className="absolute top-0 left-0 w-64 h-64 bg-indigo-500/5 blur-[80px]" />
                <h2 className="text-3xl font-medium mb-12 tracking-tight">Autonomous Agents</h2>
                <div className="space-y-8">
                  {detail.agents.map((agent, i) => (
                    <div key={i} className="flex gap-6 items-start">
                       <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center shrink-0 border border-white/5 text-xl">🤖</div>
                       <div>
                          <h4 className="font-medium text-white mb-2">{agent.title}</h4>
                          <p className="text-gray-400 text-sm font-light">{agent.desc}</p>
                       </div>
                    </div>
                  ))}
                </div>
             </div>
           </ScrollReveal>

           <ScrollReveal>
             <div className="glass-panel p-10 md:p-12 rounded-[2.5rem] relative overflow-hidden border-indigo-500/10">
                <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 blur-[80px]" />
                <h2 className="text-3xl font-medium mb-12 tracking-tight">Business Velocity</h2>
                <ul className="space-y-8">
                  {detail.benefits.map((benefit, i) => (
                    <li key={i} className="group cursor-default">
                       <div className="text-indigo-400 font-mono text-xs mb-2 uppercase tracking-widest">Result // 0{i+1}</div>
                       <h4 className="text-xl font-medium text-white mb-2 group-hover:text-indigo-200 transition-colors">{benefit.title}</h4>
                       <p className="text-gray-400 text-sm font-light leading-relaxed">{benefit.desc}</p>
                    </li>
                  ))}
                </ul>
             </div>
           </ScrollReveal>
        </div>

        {/* CTA Form */}
        <ScrollReveal>
          <section className="max-w-4xl mx-auto px-6 relative z-10">
            <div className="animated-glow-border p-12 rounded-[2.5rem]">
              <h2 className="text-3xl font-medium mb-4 text-center tracking-tight">Ready to Deploy?</h2>
              <p className="text-gray-400 font-light mb-10 text-center">Get a custom deployment strategy for your {detail.title}.</p>
              <LeadForm />
            </div>
          </section>
        </ScrollReveal>
      </main>
    </div>
  );
};
